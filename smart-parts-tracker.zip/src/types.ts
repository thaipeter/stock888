export interface Item {
  code: string;
  name: string;
  category: string;
  unit: string;
  stock: number;
  min: number;
  type: 'part' | 'tool';
}

export interface User {
  userId: string;
  name: string;
  role: 'admin' | 'user';
  dept?: string;
  pin: string;
  approved: boolean;
}

export interface ActiveBorrow {
  reqId: string;
  itemCode: string;
  itemName: string;
  qty: number;
  borrower: string;
  userId: string;
  date: string;
  remark?: string;
}

export interface TransactionHistory {
  id: string;
  type: 'เบิก' | 'ยืม' | 'คืน';
  itemCode: string;
  itemName: string;
  qty: number;
  user: string;
  userId: string;
  date: string;
  remark?: string;
}

export interface AppSettings {
  reqRemark: boolean;
  gasUrl: string;
}
