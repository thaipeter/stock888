import { Item, User, ActiveBorrow, TransactionHistory } from './types';

export const INITIAL_ITEMS: Item[] = [
  { code: 'BL-001', name: 'สายยางอุตสาหกรรม TOYOX 1/2"', category: 'ระบบน้ำ', unit: 'เมตร', stock: 48, min: 10, type: 'part' },
  { code: 'EL-012', name: 'สายไฟ THW 1x1.5 Sq.mm. (ขาว)', category: 'ไฟฟ้า', unit: 'เมตร', stock: 120, min: 20, type: 'part' },
  { code: 'ME-041', name: 'สายพานหน้าเครื่อง V-Belt B62', category: 'เครื่องจักร', unit: 'เส้น', stock: 12, min: 5, type: 'part' },
  { code: 'PN-007', name: 'น็อตหกเหลี่ยมชุบขาว M8×30', category: 'ของเบ็ดเตล็ด', unit: 'ตัว', stock: 200, min: 50, type: 'part' },
  { code: 'OL-003', name: 'น้ำมันหล่อลื่นไฮดรอลิก Shell AW68', category: 'น้ำมัน', unit: 'ลิตร', stock: 18, min: 5, type: 'part' },
  { code: 'FL-009', name: 'ฟิลเตอร์อากาศอัด SMC 1/4"', category: 'ระบบลม', unit: 'อัน', stock: 3, min: 4, type: 'part' },
  { code: 'TL-001', name: 'ประแจปากตายเดี่ยว Koken เบอร์ 13', category: 'เครื่องมือ', unit: 'อัน', stock: 3, min: 1, type: 'tool' },
  { code: 'TL-002', name: 'สว่านโรตารี่ Bosch GBH 2-26 DFR', category: 'เครื่องมือไฟฟ้า', unit: 'เครื่อง', stock: 2, min: 1, type: 'tool' },
  { code: 'TL-003', name: 'ชุดไขควงหุ้มฉนวนกันไฟ 1000V 6 ชิ้น', category: 'เครื่องมือ', unit: 'ชุด', stock: 5, min: 2, type: 'tool' },
  { code: 'TL-004', name: 'คีมปากจระเข้ตราตา 8 นิ้ว', category: 'เครื่องมือ', unit: 'อัน', stock: 4, min: 1, type: 'tool' },
  { code: 'TL-005', name: 'เครื่องวัดมัลติมิเตอร์ Fluke 117', category: 'เครื่องมือไฟฟ้า', unit: 'เครื่อง', stock: 1, min: 1, type: 'tool' },
];

export const INITIAL_USERS: User[] = [
  { userId: 'u001', name: 'สมชาย ใจดี', role: 'user', dept: 'ช่างซ่อมบำรุง', pin: '1234', approved: true },
  { userId: 'u002', name: 'วิชัย เก่งงาน', role: 'user', dept: 'ฝ่ายผลิต Line 1', pin: '5678', approved: true },
  { userId: 'u_admin', name: 'ธนาเดช (ผู้ดูแลคลัง)', role: 'admin', dept: 'ฝ่ายคลังสินค้า', pin: '0000', approved: true },
  // Unapproved demo user to test admin approvals
  { userId: 'u003', name: 'นพพล รักษ์ดี', role: 'user', dept: 'ซ่อมบำรุงไฟฟ้า', pin: '9999', approved: false }
];

export const INITIAL_BORROWS: ActiveBorrow[] = [
  { reqId: 'BW001', itemCode: 'TL-001', itemName: 'ประแจปากตายเดี่ยว Koken เบอร์ 13', qty: 1, borrower: 'สมชาย ใจดี', userId: 'u001', date: '23/06/2026', remark: 'ซ่อมปั๊มน้ำ Line 2' },
  { reqId: 'BW002', itemCode: 'TL-003', itemName: 'ชุดไขควงหุ้มฉนวนกันไฟ 1000V 6 ชิ้น', qty: 1, borrower: 'วิชัย เก่งงาน', userId: 'u002', date: '22/06/2026', remark: 'ตรวจตู้คอนโทรลตึก B' }
];

export const INITIAL_HISTORY: TransactionHistory[] = [
  { id: 'TX001', type: 'เบิก', itemCode: 'PN-007', itemName: 'น็อตหกเหลี่ยมชุบขาว M8×30', qty: 10, user: 'สมชาย ใจดี', userId: 'u001', date: '23/06/2026 14:30', remark: 'เปลี่ยนฝาครอบสายพาน' },
  { id: 'TX002', type: 'ยืม', itemCode: 'TL-001', itemName: 'ประแจปากตายเดี่ยว Koken เบอร์ 13', qty: 1, user: 'สมชาย ใจดี', userId: 'u001', date: '23/06/2026 09:15', remark: 'ซ่อมปั๊มน้ำ Line 2' }
];
