import React, { useState, useEffect } from 'react';
import { Item, User, ActiveBorrow, TransactionHistory, AppSettings } from './types';
import {
  INITIAL_ITEMS,
  INITIAL_USERS,
  INITIAL_BORROWS,
  INITIAL_HISTORY
} from './mockData';
import LoginScreen from './components/LoginScreen';
import QRScannerModal from './components/QRScannerModal';
import TransactionModal from './components/TransactionModal';
import {
  Search,
  Camera,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Plus,
  Minus,
  Settings,
  X,
  Check,
  AlertCircle,
  Clock,
  UserCheck,
  History,
  TrendingDown,
  Wrench,
  PackageCheck,
  PackageOpen,
  CornerDownRight,
  Trash2,
  RefreshCw,
  Sliders,
  CheckCircle,
  FileText
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // --- CORE STATE ---
  const [items, setItems] = useState<Item[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [borrows, setBorrows] = useState<ActiveBorrow[]>([]);
  const [history, setHistory] = useState<TransactionHistory[]>([]);
  const [settings, setSettings] = useState<AppSettings>({ reqRemark: false, gasUrl: '' });
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // --- VIEW / NAV STATE ---
  const [activeTab, setActiveTab] = useState<'withdraw' | 'borrow'>('withdraw');
  const [borrowSubTab, setBorrowSubTab] = useState<'borrow' | 'return'>('borrow');

  // --- FILTERS & SEARCH ---
  const [withdrawSearch, setWithdrawSearch] = useState<string>('');
  const [withdrawCategory, setWithdrawCategory] = useState<string>('__all__');
  const [borrowSearch, setBorrowSearch] = useState<string>('');
  const [borrowCategory, setBorrowCategory] = useState<string>('__all__');

  // --- CARTS ---
  const [withdrawCart, setWithdrawCart] = useState<any[]>([]);
  const [borrowCart, setBorrowCart] = useState<any[]>([]);

  // --- MODALS ---
  const [isScannerOpen, setIsScannerOpen] = useState<boolean>(false);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);
  const [isAdminOpen, setIsAdminOpen] = useState<boolean>(false);

  // --- TOAST LIST ---
  const [toasts, setToasts] = useState<any[]>([]);

  // --- INITIAL DATA SEED / SYNC ---
  useEffect(() => {
    // 1. Check local storage
    const storedItems = localStorage.getItem('spt_items');
    const storedUsers = localStorage.getItem('spt_users');
    const storedBorrows = localStorage.getItem('spt_borrows');
    const storedHistory = localStorage.getItem('spt_history');
    const storedSettings = localStorage.getItem('spt_settings');

    if (storedItems) setItems(JSON.parse(storedItems));
    else {
      setItems(INITIAL_ITEMS);
      localStorage.setItem('spt_items', JSON.stringify(INITIAL_ITEMS));
    }

    if (storedUsers) setUsers(JSON.parse(storedUsers));
    else {
      setUsers(INITIAL_USERS);
      localStorage.setItem('spt_users', JSON.stringify(INITIAL_USERS));
    }

    if (storedBorrows) setBorrows(JSON.parse(storedBorrows));
    else {
      setBorrows(INITIAL_BORROWS);
      localStorage.setItem('spt_borrows', JSON.stringify(INITIAL_BORROWS));
    }

    if (storedHistory) setHistory(JSON.parse(storedHistory));
    else {
      setHistory(INITIAL_HISTORY);
      localStorage.setItem('spt_history', JSON.stringify(INITIAL_HISTORY));
    }

    if (storedSettings) setSettings(JSON.parse(storedSettings));
    else {
      const initialSettings = {
        reqRemark: false,
        gasUrl: 'https://script.google.com/macros/s/AKfycbwVcL-cvscyHqLsNKzjTa8iTvCZfmUCSa-CqYaluF6T4dDtTffBsvOV1GmPLA_8_LQQ/exec'
      };
      setSettings(initialSettings);
      localStorage.setItem('spt_settings', JSON.stringify(initialSettings));
    }

    // Try to trigger auto-sync from Google Apps Script if URL works
    setTimeout(() => {
      setIsLoading(false);
    }, 850);
  }, []);

  // Sync back to local storage whenever states change
  const saveState = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // --- TOAST UTILITY ---
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now() + Math.random().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 2800);
  };

  // --- AUTHENTICATION EVENTS ---
  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    showToast(`ยินดีต้อนรับคุณ ${user.name}`, 'success');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setWithdrawCart([]);
    setBorrowCart([]);
    setIsProfileOpen(false);
    setIsAdminOpen(false);
    showToast('ออกจากระบบเรียบร้อย', 'info');
  };

  // User Registration
  const handleRegisterRequest = async (name: string, dept: string, pin: string): Promise<{ success: boolean; error?: string }> => {
    // 1. Validate if user already exists
    const exists = users.some(u => u.name.trim() === name.trim());
    if (exists) {
      return { success: false, error: 'มีชื่อผู้ใช้นี้ลงทะเบียนไว้ในระบบแล้ว' };
    }

    // 2. Create unapproved user
    const newUser: User = {
      userId: 'u' + (users.length + 1) + Math.floor(Math.random() * 1000),
      name: name.trim(),
      dept: dept.trim() || undefined,
      pin,
      role: 'user',
      approved: false
    };

    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    saveState('spt_users', updatedUsers);

    // Call Google Sheets API asynchronously if provided
    if (settings.gasUrl) {
      try {
        fetch(settings.gasUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain' },
          body: JSON.stringify({ fn: 'webRegisterUser', args: [{ name, dept, pin }] })
        });
      } catch (e) {
        console.warn('Google Sheets sync deferred:', e);
      }
    }

    return { success: true };
  };

  // --- CART MANAGEMENT ---
  const handleAddItemToCart = (itemCode: string, mode: 'withdraw' | 'borrow') => {
    const item = items.find(i => i.code === itemCode);
    if (!item) return;

    if (mode === 'withdraw' && item.stock <= 0) {
      showToast('ไม่สามารถเบิกได้เนื่องจากอะไหล่หมดสต็อก', 'error');
      return;
    }

    const cart = mode === 'withdraw' ? withdrawCart : borrowCart;
    const setCart = mode === 'withdraw' ? setWithdrawCart : setBorrowCart;

    const existing = cart.find(c => c.code === itemCode);
    if (existing) {
      if (mode === 'withdraw' && existing.qty >= item.stock) {
        showToast('จำนวนที่เลือกเต็มโควต้าคงเหลือในคลังแล้ว', 'error');
        return;
      }
      const updatedCart = cart.map(c => c.code === itemCode ? { ...c, qty: c.qty + 1 } : c);
      setCart(updatedCart);
    } else {
      const newCartItem = {
        code: item.code,
        name: item.name,
        qty: 1,
        unit: item.unit,
        stock: item.stock
      };
      setCart([...cart, newCartItem]);
    }
    showToast(`เพิ่ม ${item.name} ลงในตะกร้าเรียบร้อย`, 'success');
  };

  const handleUpdateCartQty = (index: number, qty: number, mode: 'withdraw' | 'borrow') => {
    const cart = mode === 'withdraw' ? withdrawCart : borrowCart;
    const setCart = mode === 'withdraw' ? setWithdrawCart : setBorrowCart;

    const updated = [...cart];
    updated[index].qty = qty;
    setCart(updated);
  };

  const handleRemoveCartItem = (index: number, mode: 'withdraw' | 'borrow') => {
    const cart = mode === 'withdraw' ? withdrawCart : borrowCart;
    const setCart = mode === 'withdraw' ? setWithdrawCart : setBorrowCart;

    const updated = cart.filter((_, idx) => idx !== index);
    setCart(updated);
    showToast('ลบชิ้นงานออกจากตะกร้าเรียบร้อย');
  };

  // --- SUBMIT TRANSACTION ---
  const handleTransactionSubmit = async (remark: string, mode: 'withdraw' | 'borrow') => {
    if (!currentUser) return;
    const cart = mode === 'withdraw' ? withdrawCart : borrowCart;
    const setCart = mode === 'withdraw' ? setWithdrawCart : setBorrowCart;

    // Simulate Network/Data Delay
    await new Promise(resolve => setTimeout(resolve, 800));

    // 1. Create Transaction histories & update inventory
    const newHistories: TransactionHistory[] = [];
    const newActiveBorrows: ActiveBorrow[] = [];

    // Deduct stock if withdraw
    const updatedItems = items.map(item => {
      const cartMatch = cart.find(c => c.code === item.code);
      if (cartMatch) {
        // Build History
        const txId = 'TX' + Math.floor(Math.random() * 1000000);
        const dateStr = new Date().toLocaleString('th-TH');

        newHistories.push({
          id: txId,
          type: mode === 'withdraw' ? 'เบิก' : 'ยืม',
          itemCode: item.code,
          itemName: item.name,
          qty: cartMatch.qty,
          user: currentUser.name,
          userId: currentUser.userId,
          date: dateStr,
          remark: remark || undefined
        });

        if (mode === 'borrow') {
          // Add to active borrows
          newActiveBorrows.push({
            reqId: 'BW' + Math.floor(Math.random() * 1000000),
            itemCode: item.code,
            itemName: item.name,
            qty: cartMatch.qty,
            borrower: currentUser.name,
            userId: currentUser.userId,
            date: new Date().toLocaleDateString('th-TH'),
            remark: remark || undefined
          });
        }

        const nextStock = mode === 'withdraw' ? Math.max(0, item.stock - cartMatch.qty) : item.stock;
        return { ...item, stock: nextStock };
      }
      return item;
    });

    // Save states
    setItems(updatedItems);
    saveState('spt_items', updatedItems);

    const mergedHistory = [...newHistories, ...history];
    setHistory(mergedHistory);
    saveState('spt_history', mergedHistory);

    if (newActiveBorrows.length > 0) {
      const mergedBorrows = [...borrows, ...newActiveBorrows];
      setBorrows(mergedBorrows);
      saveState('spt_borrows', mergedBorrows);
    }

    // Reset Cart
    setCart([]);
    showToast(`ทำรายการบันทึก ${cart.length} ชิ้น สำเร็จแล้ว!`, 'success');

    // Async sync to Google Sheets if configured
    if (settings.gasUrl) {
      try {
        const payloads = cart.map(item => ({
          code: item.code,
          qty: item.qty,
          type: mode === 'withdraw' ? 'เบิก' : 'ยืม',
          user: currentUser.name,
          uid: currentUser.userId,
          remark
        }));
        fetch(settings.gasUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain' },
          body: JSON.stringify({ fn: 'webBatchTransaction', args: [payloads] })
        });
      } catch (e) {
        console.warn('Sync to Google Sheets failed:', e);
      }
    }
  };

  // --- RETURN ITEM HANDLER ---
  const handleReturnItem = async (borrow: ActiveBorrow) => {
    // 1. Confirm Dialog
    const confirm = window.confirm(`คุณแน่ใจหรือไม่ที่จะคืนเครื่องมือ: ${borrow.itemName} จำนวน ${borrow.qty} ชิ้น?`);
    if (!confirm) return;

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    // Deduct/Remove from active borrows
    const nextBorrows = borrows.filter(b => b.reqId !== borrow.reqId);
    setBorrows(nextBorrows);
    saveState('spt_borrows', nextBorrows);

    // Save to history logs
    const dateStr = new Date().toLocaleString('th-TH');
    const newTx: TransactionHistory = {
      id: 'TX' + Math.floor(Math.random() * 1000000),
      type: 'คืน',
      itemCode: borrow.itemCode,
      itemName: borrow.itemName,
      qty: borrow.qty,
      user: currentUser?.name || borrow.borrower,
      userId: currentUser?.userId || borrow.userId,
      date: dateStr,
      remark: 'คืนสำเร็จ'
    };

    const nextHistory = [newTx, ...history];
    setHistory(nextHistory);
    saveState('spt_history', nextHistory);

    // No need to restock unless it's a part, but tools also keep their stocks!
    // Let's add back the tool stock
    const nextItems = items.map(item => {
      if (item.code === borrow.itemCode) {
        return { ...item, stock: item.stock + borrow.qty };
      }
      return item;
    });
    setItems(nextItems);
    saveState('spt_items', nextItems);

    setIsLoading(false);
    showToast(`คืน ${borrow.itemName} สำเร็จเรียบร้อย`, 'success');

    // Google Sheets Sync
    if (settings.gasUrl) {
      try {
        fetch(settings.gasUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'text/plain' },
          body: JSON.stringify({ fn: 'webReturnItem', args: [borrow.reqId, currentUser?.name || borrow.borrower, currentUser?.userId || borrow.userId] })
        });
      } catch (e) {
        console.warn('Sync to Google Sheets failed:', e);
      }
    }
  };

  // --- ADMIN PANEL ACTIONS ---
  const handleApproveUser = (userId: string) => {
    const nextUsers = users.map(u => u.userId === userId ? { ...u, approved: true } : u);
    setUsers(nextUsers);
    saveState('spt_users', nextUsers);
    showToast('อนุมัติผู้ใช้งานคนใหม่เรียบร้อยแล้ว');
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('คุณต้องการลบสิทธิ์ผู้ใช้งานคนนี้หรือไม่?')) {
      const nextUsers = users.filter(u => u.userId !== userId);
      setUsers(nextUsers);
      saveState('spt_users', nextUsers);
      showToast('ลบสิทธิ์ผู้ใช้งานเรียบร้อย');
    }
  };

  const handleAddNewItem = (newItem: Item) => {
    const exists = items.some(i => i.code.trim().toUpperCase() === newItem.code.trim().toUpperCase());
    if (exists) {
      showToast('รหัสชิ้นงานนี้ซ้ำกับที่มีอยู่แล้ว', 'error');
      return;
    }
    const nextItems = [...items, newItem];
    setItems(nextItems);
    saveState('spt_items', nextItems);
    showToast(`เพิ่มอะไหล่ใหม่สำเร็จ: ${newItem.name}`, 'success');
  };

  const handleUpdateItemStock = (code: string, increment: number) => {
    const nextItems = items.map(item => {
      if (item.code === code) {
        return { ...item, stock: Math.max(0, item.stock + increment) };
      }
      return item;
    });
    setItems(nextItems);
    saveState('spt_items', nextItems);
    showToast('ปรับสต็อกเรียบร้อย');
  };

  const handleSettingsSave = (newSettings: AppSettings) => {
    setSettings(newSettings);
    saveState('spt_settings', newSettings);
    showToast('บันทึกการตั้งค่าเรียบร้อย', 'success');
  };

  const handleResetToDefault = () => {
    if (window.confirm('คำเตือน: คุณแน่ใจที่จะล้างข้อมูลเป็นค่าเริ่มต้นทั้งหมดหรือไม่?')) {
      setItems(INITIAL_ITEMS);
      setUsers(INITIAL_USERS);
      setBorrows(INITIAL_BORROWS);
      setHistory(INITIAL_HISTORY);
      
      saveState('spt_items', INITIAL_ITEMS);
      saveState('spt_users', INITIAL_USERS);
      saveState('spt_borrows', INITIAL_BORROWS);
      saveState('spt_history', INITIAL_HISTORY);
      
      showToast('รีเซ็ตข้อมูลทั้งหมดเรียบร้อยแล้ว', 'success');
    }
  };

  // --- FILTER COMPUTATIONS ---
  const activeCategoriesMap = (mode: 'withdraw' | 'borrow') => {
    const list = items.filter(i => mode === 'withdraw' ? i.type === 'part' : i.type === 'tool');
    const cats: Record<string, { count: number; items: Item[] }> = {};
    list.forEach(item => {
      const cat = item.category || 'อื่นๆ';
      if (!cats[cat]) cats[cat] = { count: 0, items: [] };
      cats[cat].count++;
      cats[cat].items.push(item);
    });
    return cats;
  };

  const getFilteredItems = (mode: 'withdraw' | 'borrow') => {
    const search = mode === 'withdraw' ? withdrawSearch : borrowSearch;
    const cat = mode === 'withdraw' ? withdrawCategory : borrowCategory;

    return items.filter(item => {
      // 1. Type match
      const typeMatch = mode === 'withdraw' ? item.type === 'part' : item.type === 'tool';
      if (!typeMatch) return false;

      // 2. Category match
      if (cat !== '__all__' && item.category !== cat) return false;

      // 3. Search text match
      if (search.trim()) {
        const query = search.toLowerCase();
        const codeMatch = item.code.toLowerCase().includes(query);
        const nameMatch = item.name.toLowerCase().includes(query);
        const catMatch = item.category.toLowerCase().includes(query);
        return codeMatch || nameMatch || catMatch;
      }

      return true;
    });
  };

  // Helper mapping of Thai emojis for categories
  const categoryIcons: Record<string, string> = {
    'ระบบน้ำ': '🚰',
    'ไฟฟ้า': '⚡',
    'เครื่องจักร': '⚙️',
    'น้ำมัน': '🛢️',
    'ระบบลม': '💨',
    'เครื่องมือ': '🔧',
    'เครื่องมือไฟฟ้า': '🔌',
    'ของเบ็ดเตล็ด': '📦',
    'default': '📦'
  };

  const getCatIcon = (cat: string) => categoryIcons[cat] || categoryIcons['default'];

  // User-specific borrows count
  const myBorrows = borrows.filter(b =>
    currentUser?.role === 'admin' || b.userId === currentUser?.userId
  );

  // Critical Low Stock Check
  const criticalLowItems = items.filter(i => i.stock <= i.min);

  // If user not logged in, render PIN login page
  if (!currentUser) {
    return (
      <>
        {isLoading && (
          <div className="fixed inset-0 bg-[#0d0e12] z-[100] flex flex-col items-center justify-center gap-4">
            <div className="w-10 h-10 border-3 border-amber-500 border-t-transparent rounded-full animate-spin" />
            <span className="text-sm text-slate-400 font-medium">กำลังโหลดข้อมูลระบบคลัง...</span>
          </div>
        )}
        <LoginScreen
          users={users}
          onLoginSuccess={handleLoginSuccess}
          onRegisterRequest={handleRegisterRequest}
        />
        {/* Toast Alerts Overlay */}
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[200] flex flex-col gap-2 pointer-events-none w-full max-w-sm px-4">
          {toasts.map(t => (
            <div
              key={t.id}
              className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2 shadow-xl backdrop-blur-md animate-[slideUp_0.2s_ease-out] ${
                t.type === 'success'
                  ? 'bg-emerald-950/90 border-emerald-500/30 text-emerald-400'
                  : t.type === 'error'
                  ? 'bg-rose-950/90 border-rose-500/30 text-rose-400'
                  : 'bg-slate-900/95 border-slate-700/50 text-slate-200'
              }`}
            >
              <span>{t.type === 'success' ? '✓' : t.type === 'error' ? '✕' : 'ℹ'}</span>
              <span>{t.message}</span>
            </div>
          ))}
        </div>
      </>
    );
  }

  return (
    <div className="min-h-screen bg-[#0F172A] flex flex-col text-slate-200">
      
      {/* ── TOP NAV BAR ── */}
      <header className="bg-slate-900/40 backdrop-blur-md border-b border-slate-800/30 sticky top-0 z-30 flex-shrink-0">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          
          {/* Logo Title */}
          <div className="flex items-center gap-2.5">
            <span className="text-2xl animate-[pulse_3s_infinite]">🏭</span>
            <div>
              <h2 className="text-sm font-bold text-slate-100 leading-tight">คลังอะไหล่อัจฉริยะ</h2>
              <span className="text-[10px] text-indigo-400 font-mono tracking-wider">SMART PARTS TRACKER</span>
            </div>
          </div>

          {/* User Details & Profile Button */}
          <div className="flex items-center gap-2.5">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-200">{currentUser.name}</div>
              <div className="text-[10px] text-indigo-400 font-medium">{currentUser.dept || 'ทั่วไป'} • {currentUser.role === 'admin' ? 'ผู้ดูแลคลัง' : 'ช่างซ่อม'}</div>
            </div>

            {/* Profile Avatar / Settings click */}
            <button
              onClick={() => setIsProfileOpen(true)}
              className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-0.5 shadow-lg shadow-indigo-500/10 active:scale-95 transition-transform cursor-pointer"
            >
              <div className="w-full h-full rounded-[10px] bg-slate-900 flex items-center justify-center font-bold text-indigo-400 text-sm">
                {currentUser.name.charAt(0).toUpperCase()}
              </div>
            </button>
          </div>
        </div>
      </header>

      {/* ── METRICS DASHBOARD STATUS ── */}
      <section className="py-4 flex-shrink-0">
        <div className="max-w-4xl mx-auto px-4 grid grid-cols-3 gap-3">
          <div className="bento-card p-3 sm:p-4 text-center relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-500/5 rounded-bl-full pointer-events-none transition-transform group-hover:scale-110" />
            <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">จำนวนอะไหล่ทั้งหมด</div>
            <div className="text-lg sm:text-2xl font-bold text-slate-100 font-mono mt-1">{items.length} <span className="text-[10px] font-normal text-slate-400">รายการ</span></div>
          </div>
          <div className="bento-card p-3 sm:p-4 text-center relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-rose-500/5 rounded-bl-full pointer-events-none transition-transform group-hover:scale-110" />
            <div className="text-[10px] text-rose-400 font-bold uppercase tracking-wider">ใกล้หมดสต็อก</div>
            <div className="text-lg sm:text-2xl font-bold text-rose-400 font-mono mt-1">{criticalLowItems.length} <span className="text-[10px] font-normal text-rose-400/70">ชิ้น</span></div>
          </div>
          <div className="bento-card p-3 sm:p-4 text-center relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/5 rounded-bl-full pointer-events-none transition-transform group-hover:scale-110" />
            <div className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">ค้างยืมเครื่องมือ</div>
            <div className="text-lg sm:text-2xl font-bold text-blue-400 font-mono mt-1">{borrows.length} <span className="text-[10px] font-normal text-blue-400/70">ชิ้น</span></div>
          </div>
        </div>
      </section>

      {/* ── TWO MAIN MODULE TABS ── */}
      <div className="max-w-4xl mx-auto w-full px-4 flex-shrink-0 mb-2">
        <div className="bg-slate-900/60 p-1.5 rounded-2xl border border-slate-800/40 flex gap-2">
          <button
            onClick={() => {
              setActiveTab('withdraw');
              setWithdrawCategory('__all__');
            }}
            className={`flex-1 py-3 text-center font-bold text-xs sm:text-sm tracking-wide transition-all rounded-xl flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'withdraw'
                ? 'bg-gradient-to-r from-rose-500/15 to-pink-500/10 text-rose-400 border border-rose-500/20 shadow-md shadow-rose-500/5'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/20'
            }`}
          >
            <span>📤</span> เบิกจ่ายอะไหล่
          </button>
          
          <button
            onClick={() => {
              setActiveTab('borrow');
              setBorrowCategory('__all__');
            }}
            className={`flex-1 py-3 text-center font-bold text-xs sm:text-sm tracking-wide transition-all rounded-xl border flex items-center justify-center gap-2 cursor-pointer ${
              activeTab === 'borrow'
                ? 'bg-gradient-to-r from-indigo-500/15 to-blue-500/10 text-indigo-400 border-indigo-500/20 shadow-md shadow-indigo-500/5'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/20'
            }`}
          >
            <span>🤝</span> ยืม / คืนเครื่องมือ
          </button>
        </div>
      </div>

      {/* ── MAIN SCENE BODY ── */}
      <main className="flex-1 overflow-y-auto max-w-4xl mx-auto w-full px-4 py-4 pb-28">
        
        {/* TAB 1: WITHDRAW PILL FLOW */}
        {activeTab === 'withdraw' && (
          <div className="space-y-4 animate-[fadeIn_0.2s_ease-out]">
            
            {/* Search and camera control row */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={withdrawSearch}
                  onChange={(e) => {
                    setWithdrawSearch(e.target.value);
                    if (e.target.value.trim() && withdrawCategory !== '__all__') {
                      setWithdrawCategory('__all__');
                    }
                  }}
                  placeholder="ค้นหาชื่ออะไหล่ หรือ สแกนคิวอาร์โค้ด..."
                  className="w-full bg-slate-900/60 border border-slate-800/60 text-slate-200 pl-10 pr-4 py-3 rounded-xl text-xs sm:text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500/50 transition-all placeholder-slate-500"
                />
                {withdrawSearch && (
                  <button
                    onClick={() => setWithdrawSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <button
                onClick={() => setIsScannerOpen(true)}
                className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold px-4 py-3 rounded-xl text-xs sm:text-sm flex items-center gap-1.5 transition-all cursor-pointer shadow-lg shadow-indigo-600/15 shrink-0"
              >
                <Camera className="w-4.5 h-4.5" /> <span className="hidden sm:inline">สแกนชิ้นงาน</span>
              </button>
            </div>

            {/* Category Select Screen */}
            {withdrawCategory === '__all__' && !withdrawSearch.trim() ? (
              <div className="space-y-3">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider pl-1">
                  เลือกหมวดหมู่ อะไหล่ / วัสดุชิ้นงาน
                </h3>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {/* All items card */}
                  <div
                    onClick={() => setWithdrawCategory('__all_selected__')}
                    className="p-4 bento-card cursor-pointer active:scale-98 transition-all flex items-center gap-3"
                  >
                    <div className="w-10 h-10 rounded-xl bg-slate-800/60 flex items-center justify-center text-xl">🗂️</div>
                    <div>
                      <h4 className="font-semibold text-xs sm:text-sm text-slate-200">ทั้งหมด</h4>
                      <p className="text-[10px] text-indigo-400/80 mt-0.5">{items.filter(i => i.type === 'part').length} รายการ</p>
                    </div>
                  </div>

                  {/* Dynamic Category Blocks */}
                  {Object.entries(activeCategoriesMap('withdraw')).map(([cat, info]) => {
                    const hasOutOfStock = info.items.every(i => i.stock <= 0);
                    return (
                      <div
                        key={cat}
                        onClick={() => setWithdrawCategory(cat)}
                        className="p-4 bento-card cursor-pointer active:scale-98 transition-all flex flex-col justify-between gap-3 min-h-[95px]"
                      >
                        <div className="flex justify-between items-start">
                          <div className="w-10 h-10 rounded-xl bg-slate-800/60 flex items-center justify-center text-xl">
                            {getCatIcon(cat)}
                          </div>
                          {hasOutOfStock && (
                            <span className="text-[9px] bg-rose-500/10 text-rose-400 border border-rose-500/20 px-1.5 py-0.5 rounded font-bold">หมด</span>
                          )}
                        </div>
                        <div>
                          <h4 className="font-semibold text-xs sm:text-sm text-slate-200 truncate">{cat}</h4>
                          <p className="text-[10px] text-indigo-400/80 mt-0.5">{info.count} รายการ</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* Selected Category Inventory List View */
              <div className="space-y-3">
                <div className="flex items-center justify-between pl-1">
                  <button
                    onClick={() => {
                      setWithdrawCategory('__all__');
                      setWithdrawSearch('');
                    }}
                    className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" /> ย้อนกลับหมวดหมู่
                  </button>

                  <span className="text-[11px] font-bold text-rose-400 bg-rose-500/10 border border-rose-500/20 px-2.5 py-1 rounded-full">
                    {withdrawCategory === '__all_selected__' ? 'ทั้งหมด' : withdrawCategory || `ผลลัพธ์การค้นหา`}
                  </span>
                </div>

                {/* Items loop */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {getFilteredItems('withdraw').length === 0 ? (
                    <div className="col-span-full text-center py-12 bento-card text-slate-400 text-xs sm:text-sm">
                      ไม่พบอะไหล่ในหมวดนี้
                    </div>
                  ) : (
                    getFilteredItems('withdraw').map(item => {
                      const inCart = withdrawCart.find(c => c.code === item.code);
                      const isLowStock = item.stock <= item.min;
                      const isOutOfStock = item.stock <= 0;

                      return (
                        <div
                          key={item.code}
                          onClick={() => handleAddItemToCart(item.code, 'withdraw')}
                          className={`p-4 bento-card cursor-pointer transition-all flex items-center gap-3.5 select-none relative group overflow-hidden ${
                            inCart
                              ? 'border-emerald-500/40 bg-emerald-950/20'
                              : isOutOfStock
                              ? 'opacity-50'
                              : isLowStock
                              ? 'border-amber-500/30'
                              : ''
                          }`}
                        >
                          {/* Left Icon Display */}
                          <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-xl shrink-0 ${
                            isOutOfStock ? 'bg-slate-800/40' : 'bg-slate-900 border border-slate-800/40'
                          }`}>
                            {getCatIcon(item.category)}
                          </div>

                          {/* Center info */}
                          <div className="min-w-0 flex-1">
                            <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-slate-400">
                              {item.code}
                            </span>
                            <h4 className="font-semibold text-slate-100 text-xs sm:text-sm truncate mt-0.5 group-hover:text-indigo-400 transition-colors">
                              {item.name}
                            </h4>
                            <div className="flex items-center gap-1.5 mt-1">
                              {inCart && (
                                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-bold flex items-center gap-0.5">
                                  ✓ ในตะกร้า ×{inCart.qty}
                                </span>
                              )}
                              {isOutOfStock ? (
                                <span className="text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/20 px-1.5 py-0.5 rounded font-bold">
                                  หมดคลัง
                                </span>
                              ) : isLowStock ? (
                                <span className="text-[10px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-1.5 py-0.5 rounded font-bold">
                                  สต็อกต่ำ
                                </span>
                              ) : null}
                            </div>
                          </div>

                          {/* Right side Stock quantities */}
                          <div className="text-right shrink-0">
                            <span className={`text-base font-bold font-mono ${
                              isOutOfStock ? 'text-rose-500' : isLowStock ? 'text-amber-500' : 'text-slate-200'
                            }`}>
                              {item.stock}
                            </span>
                            <span className="text-[10px] text-slate-500 block">{item.unit}</span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: BORROW / RETURN INSTRUMENT PILL FLOW */}
        {activeTab === 'borrow' && (
          <div className="space-y-4 animate-[fadeIn_0.2s_ease-out]">
            
            {/* Sub-tabs for Borrow & Return */}
            <div className="flex bg-slate-900/60 p-1 rounded-2xl border border-slate-800/40">
              <button
                onClick={() => setBorrowSubTab('borrow')}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  borrowSubTab === 'borrow'
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/15'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                📥 ขอยืมเครื่องมือ
              </button>
              
              <button
                onClick={() => setBorrowSubTab('return')}
                className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  borrowSubTab === 'return'
                    ? 'bg-slate-800/40 text-indigo-400 border border-indigo-500/20'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                🔄 รายการค้างส่งคืน ({myBorrows.length})
              </button>
            </div>

            {/* Sub-tab 1: Borrow Inventory Selection */}
            {borrowSubTab === 'borrow' && (
              <div className="space-y-4">
                {/* Search bar */}
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={borrowSearch}
                      onChange={(e) => {
                        setBorrowSearch(e.target.value);
                        if (e.target.value.trim() && borrowCategory !== '__all__') {
                          setBorrowCategory('__all__');
                        }
                      }}
                      placeholder="ค้นหาเครื่องมืออุตสาหกรรม หรือ สแกนคิวอาร์..."
                      className="w-full bg-slate-900/60 border border-slate-800/60 text-slate-200 pl-10 pr-4 py-3 rounded-xl text-xs sm:text-sm outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500/50 transition-all placeholder-slate-500"
                    />
                    {borrowSearch && (
                      <button
                        onClick={() => setBorrowSearch('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <button
                    onClick={() => setIsScannerOpen(true)}
                    className="bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white font-bold px-4 py-3 rounded-xl text-xs sm:text-sm flex items-center gap-1.5 transition-all cursor-pointer shadow-lg shadow-indigo-600/15 shrink-0"
                  >
                    <Camera className="w-4.5 h-4.5" /> <span className="hidden sm:inline">สแกนชิ้นงาน</span>
                  </button>
                </div>

                {/* Categories view */}
                {borrowCategory === '__all__' && !borrowSearch.trim() ? (
                  <div className="space-y-3">
                    <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider pl-1">
                      เลือกหมวดหมู่ เครื่องมือช่างอุตสาหกรรม
                    </h3>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      <div
                        onClick={() => setBorrowCategory('__all_selected__')}
                        className="p-4 bento-card cursor-pointer active:scale-98 transition-all flex items-center gap-3"
                      >
                        <div className="w-10 h-10 rounded-xl bg-slate-800/60 flex items-center justify-center text-xl">🗂️</div>
                        <div>
                          <h4 className="font-semibold text-xs sm:text-sm text-slate-200">ทั้งหมด</h4>
                          <p className="text-[10px] text-indigo-400/80 mt-0.5">{items.filter(i => i.type === 'tool').length} รายการ</p>
                        </div>
                      </div>

                      {Object.entries(activeCategoriesMap('borrow')).map(([cat, info]) => (
                        <div
                          key={cat}
                          onClick={() => setBorrowCategory(cat)}
                          className="p-4 bento-card cursor-pointer active:scale-98 transition-all flex flex-col justify-between gap-3 min-h-[95px]"
                        >
                          <div className="w-10 h-10 rounded-xl bg-slate-800/60 flex items-center justify-center text-xl">
                            {getCatIcon(cat)}
                          </div>
                          <div>
                            <h4 className="font-semibold text-xs sm:text-sm text-slate-200 truncate">{cat}</h4>
                            <p className="text-[10px] text-indigo-400/80 mt-0.5">{info.count} รายการ</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  /* Tool Inventory List View */
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pl-1">
                      <button
                        onClick={() => {
                          setBorrowCategory('__all__');
                          setBorrowSearch('');
                        }}
                        className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" /> ย้อนกลับหมวดหมู่
                      </button>

                      <span className="text-[11px] font-bold text-indigo-400 bg-indigo-500/10 border border-indigo-500/20 px-2.5 py-1 rounded-full">
                        {borrowCategory === '__all_selected__' ? 'ทั้งหมด' : borrowCategory || `ผลลัพธ์การค้นหา`}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {getFilteredItems('borrow').length === 0 ? (
                        <div className="col-span-full text-center py-12 bento-card text-slate-400 text-xs sm:text-sm">
                          ไม่พบเครื่องมือในหมวดนี้
                        </div>
                      ) : (
                        getFilteredItems('borrow').map(item => {
                          const inCart = borrowCart.find(c => c.code === item.code);
                          const isOutOfStock = item.stock <= 0;

                          return (
                            <div
                              key={item.code}
                              onClick={() => handleAddItemToCart(item.code, 'borrow')}
                              className={`p-4 bento-card cursor-pointer transition-all flex items-center gap-3.5 select-none relative group overflow-hidden ${
                                inCart
                                  ? 'border-emerald-500/40 bg-emerald-950/20'
                                  : isOutOfStock
                                  ? 'opacity-50'
                                  : ''
                              }`}
                            >
                              <div className="w-11 h-11 rounded-xl bg-slate-900 border border-slate-800/40 flex items-center justify-center text-xl shrink-0">
                                {getCatIcon(item.category)}
                              </div>

                              <div className="min-w-0 flex-1">
                                <span className="text-[10px] uppercase font-mono tracking-wider font-semibold text-slate-400">
                                  {item.code}
                                </span>
                                <h4 className="font-semibold text-slate-100 text-xs sm:text-sm truncate mt-0.5 group-hover:text-indigo-400 transition-colors">
                                  {item.name}
                                </h4>
                                <div className="flex items-center gap-1.5 mt-1">
                                  {inCart && (
                                    <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-bold flex items-center gap-0.5">
                                      ✓ เลือกแล้ว ×{inCart.qty}
                                    </span>
                                  )}
                                  {isOutOfStock && (
                                    <span className="text-[10px] bg-rose-500/10 text-rose-400 border border-rose-500/20 px-1.5 py-0.5 rounded font-bold">
                                      โดนยืมหมดแล้ว
                                    </span>
                                  )}
                                </div>
                              </div>

                              <div className="text-right shrink-0">
                                <span className={`text-base font-bold font-mono ${
                                  isOutOfStock ? 'text-rose-500' : 'text-slate-200'
                                }`}>
                                  {item.stock}
                                </span>
                                <span className="text-[10px] text-slate-500 block">{item.unit}</span>
                              </div>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Sub-tab 2: Return borrowed active list */}
            {borrowSubTab === 'return' && (
              <div className="space-y-3">
                <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider pl-1">
                  รายการเครื่องมืออุตสาหกรรมที่ค้างชำระ / ค้างส่งคืน
                </h3>

                <div className="space-y-2.5">
                  {myBorrows.length === 0 ? (
                    <div className="text-center py-12 bento-card text-slate-400 text-xs sm:text-sm flex flex-col items-center justify-center gap-2">
                      <span className="text-2xl">🎉</span>
                      <span>คุณไม่มีรายการค้างยืมเครื่องมือในขณะนี้</span>
                    </div>
                  ) : (
                    myBorrows.map(borrow => (
                      <div
                        key={borrow.reqId}
                        className="p-4 bento-card flex items-center justify-between gap-4"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase bg-indigo-500/10 border border-indigo-500/20 px-1.5 py-0.5 rounded">
                              {borrow.itemCode}
                            </span>
                            <span className="text-[10px] font-mono text-slate-500">{borrow.date}</span>
                          </div>
                          
                          <h4 className="font-semibold text-slate-200 text-xs sm:text-sm mt-1.5 truncate">
                            {borrow.itemName}
                          </h4>
                          
                          <p className="text-xs text-slate-400 mt-1 flex items-center gap-1">
                            <span>ผู้ยืม:</span>
                            <span className="font-medium text-slate-200">{borrow.borrower}</span>
                            <span>• จำนวน:</span>
                            <span className="font-bold text-indigo-400 font-mono">{borrow.qty}</span>
                          </p>

                          {borrow.remark && (
                            <div className="text-[11px] text-slate-400 mt-1.5 bg-slate-950/40 p-2 rounded-lg italic flex items-start gap-1 border border-slate-800/40">
                              <span className="text-slate-500 not-italic">หมายเหตุ:</span>
                              <span className="truncate">{borrow.remark}</span>
                            </div>
                          )}
                        </div>

                        <button
                          onClick={() => handleReturnItem(borrow)}
                          className="bg-emerald-500/10 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/20 px-4 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer flex items-center gap-1 shrink-0"
                        >
                          <span>🔄</span> คืนของ
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* ── FOOTER STICKY BASKET CONTROL ── */}
      <AnimatePresence>
        {((activeTab === 'withdraw' && withdrawCart.length > 0) ||
          (activeTab === 'borrow' && borrowSubTab === 'borrow' && borrowCart.length > 0)) && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 50, opacity: 0 }}
            className="fixed bottom-0 inset-x-0 bg-slate-900/80 backdrop-blur-md border-t border-slate-800/40 p-4 pb-safe-bottom shadow-[0_-10px_25px_rgba(0,0,0,0.5)] z-40"
          >
            <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
              <div>
                <p className="text-[11px] text-slate-400">ตะกร้าอะไหล่ที่รอการยืนยัน</p>
                <div className="text-sm font-bold text-slate-200 mt-0.5">
                  เลือกไว้{' '}
                  <span className="text-indigo-400 font-mono font-bold">
                    {activeTab === 'withdraw' ? withdrawCart.length : borrowCart.length}
                  </span>{' '}
                  รายการ
                </div>
              </div>

              <button
                onClick={() => setIsCartOpen(true)}
                className="py-3 px-6 rounded-xl text-xs sm:text-sm font-bold shadow-lg transition-all active:scale-95 cursor-pointer flex items-center gap-1.5 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white hover:opacity-90 shadow-indigo-500/10"
              >
                <span>ตรวจสอบตะกร้า & ยืนยัน</span> <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── MODAL 1: PROFILE & SETTINGS ── */}
      <AnimatePresence>
        {isProfileOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0" onClick={() => setIsProfileOpen(false)} />
            
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-md bg-slate-900/90 backdrop-blur-md border border-slate-800/80 rounded-3xl overflow-hidden shadow-2xl relative z-10"
            >
              <div className="p-6 text-center border-b border-slate-800/40 bg-slate-900/50">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 p-0.5 mx-auto mb-3 shadow-lg">
                  <div className="w-full h-full rounded-[14px] bg-slate-900 flex items-center justify-center font-bold text-indigo-400 text-xl">
                    {currentUser.name.charAt(0).toUpperCase()}
                  </div>
                </div>
                <h3 className="font-bold text-slate-100 text-base">{currentUser.name}</h3>
                <p className="text-xs text-indigo-400 mt-1 font-mono uppercase tracking-wider">
                  {currentUser.role === 'admin' ? '🛡️ ผู้ดูแลระบบคลังสินค้า' : 'ช่างซ่อมบำรุง / ผู้ทำรายการ'}
                </p>
                {currentUser.dept && (
                  <span className="inline-block bg-slate-800/60 text-slate-400 text-[10px] px-2.5 py-1 rounded-full mt-2 font-medium">
                    แผนก: {currentUser.dept}
                  </span>
                )}
              </div>

              <div className="p-4 space-y-2">
                {currentUser.role === 'admin' && (
                  <button
                    onClick={() => {
                      setIsAdminOpen(true);
                      setIsProfileOpen(false);
                    }}
                    className="w-full bg-slate-950/40 border border-slate-800/60 hover:border-slate-700 hover:bg-slate-800/20 text-slate-200 py-3 px-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-between cursor-pointer"
                  >
                    <span className="flex items-center gap-2">🛡️ หน้าควบคุมระบบผู้ดูแล (Admin Control)</span>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                )}

                <button
                  onClick={handleLogout}
                  className="w-full bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 hover:border-rose-500/40 text-rose-400 py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" /> ออกจากระบบ
                </button>
              </div>

              <div className="bg-slate-950/60 py-3.5 px-4 text-center border-t border-slate-800/40 flex justify-between items-center text-[10px] text-slate-500 font-mono">
                <span>เวอร์ชัน: 4.1.0-React</span>
                <button
                  onClick={() => setIsProfileOpen(false)}
                  className="text-slate-400 hover:text-slate-200 cursor-pointer font-sans"
                >
                  ปิดหน้าต่าง
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ── MODAL 2: ADMIN CONTROL CENTER ── */}
      <AnimatePresence>
        {isAdminOpen && (
          <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-sm z-50 flex items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ scale: 0.98, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.98, opacity: 0 }}
              className="w-full sm:max-w-2xl h-full sm:h-[90vh] bg-slate-900/95 sm:border border-slate-800 sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="p-5 border-b border-slate-800/40 bg-slate-900/50 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5">
                  <span className="text-xl">🛡️</span>
                  <div>
                    <h3 className="font-bold text-slate-100 text-sm sm:text-base">ระบบแผงควบคุมแอดมิน (Admin Settings)</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">อนุมัติสมาชิก จัดการสต็อก และตั้งค่าการเชื่อมต่อ API</p>
                  </div>
                </div>
                <button
                  onClick={() => setIsAdminOpen(false)}
                  className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Content Container */}
              <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-6">
                
                {/* PART A: PENDING USER APPROVALS */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4" /> สมาชิกที่รอการอนุมัติเข้าระบบ ({users.filter(u => !u.approved).length})
                    </h4>
                  </div>

                  <div className="space-y-2">
                    {users.filter(u => !u.approved).length === 0 ? (
                      <div className="text-center py-4 bg-slate-950/30 border border-slate-800/60 rounded-2xl text-slate-500 text-xs italic">
                        ไม่มีสมาชิกที่ค้างรอการอนุมัติในขณะนี้
                      </div>
                    ) : (
                      users.filter(u => !u.approved).map(pendingUser => (
                        <div
                          key={pendingUser.userId}
                          className="p-3.5 bg-slate-950/30 border border-slate-800/60 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div>
                            <div className="text-xs font-bold text-slate-200">{pendingUser.name}</div>
                            <div className="text-[10px] text-slate-400 mt-1">
                              แผนก: {pendingUser.dept || 'ทั่วไป'} • รหัส PIN: <span className="font-mono font-bold text-indigo-400">{pendingUser.pin}</span>
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <button
                              onClick={() => handleDeleteUser(pendingUser.userId)}
                              className="flex-1 sm:flex-none bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer"
                            >
                              ปฏิเสธ
                            </button>
                            <button
                              onClick={() => handleApproveUser(pendingUser.userId)}
                              className="flex-1 sm:flex-none bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-0.5 justify-center"
                            >
                              <Check className="w-3.5 h-3.5" /> อนุมัติสิทธิ์
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* PART B: STOCK QUICK MANAGEMENT */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Wrench className="w-4 h-4" /> ปรับปรุงปริมาณอะไหล่คลังสินค้าด่วน
                  </h4>

                  <div className="max-h-48 overflow-y-auto space-y-2 border border-slate-800/60 p-2 rounded-2xl bg-slate-950/30 pr-1">
                    {items.map(item => (
                      <div
                        key={item.code}
                        className="p-2.5 bg-slate-900/40 border border-slate-800/40 rounded-xl flex items-center justify-between gap-4"
                      >
                        <div className="min-w-0">
                          <span className="text-[9px] font-mono font-bold text-slate-400 uppercase">{item.code}</span>
                          <h5 className="font-semibold text-slate-200 text-xs truncate">{item.name}</h5>
                        </div>

                        <div className="flex items-center gap-2.5 shrink-0">
                          <button
                            onClick={() => handleUpdateItemStock(item.code, -10)}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 w-8 h-7 rounded text-xs font-bold transition-all cursor-pointer"
                            title="-10"
                          >
                            -10
                          </button>
                          <button
                            onClick={() => handleUpdateItemStock(item.code, -1)}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 w-7 h-7 rounded text-xs font-bold transition-all cursor-pointer"
                            title="-1"
                          >
                            -1
                          </button>
                          <span className="w-10 text-center text-xs font-mono font-bold text-indigo-400">
                            {item.stock}
                          </span>
                          <button
                            onClick={() => handleUpdateItemStock(item.code, 1)}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 w-7 h-7 rounded text-xs font-bold transition-all cursor-pointer"
                            title="+1"
                          >
                            +1
                          </button>
                          <button
                            onClick={() => handleUpdateItemStock(item.code, 10)}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 w-8 h-7 rounded text-xs font-bold transition-all cursor-pointer"
                            title="+10"
                          >
                            +10
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* PART C: API CONNECTIONS & CONFIGS */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Settings className="w-4 h-4" /> ตั้งค่าระบบและการเชื่อมโยง Google Sheets API
                  </h4>

                  <div className="p-4 bg-slate-950/30 border border-slate-800/60 rounded-2xl space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-slate-200">บังคับระบุหมายเหตุการทำรายการ</div>
                        <p className="text-[10px] text-slate-400 mt-0.5">ผู้ทำรายการเบิก/ยืม ต้องกรอกช่องเหตุผลประกอบการเบิกใช้</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={settings.reqRemark}
                        onChange={(e) => handleSettingsSave({ ...settings, reqRemark: e.target.checked })}
                        className="w-4 h-4 accent-indigo-500 rounded cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1.5 border-t border-slate-800/40 pt-3">
                      <label className="block text-[11px] font-bold text-slate-300">
                        URL ของ Google Apps Script Web App
                      </label>
                      <input
                        type="text"
                        value={settings.gasUrl}
                        onChange={(e) => handleSettingsSave({ ...settings, gasUrl: e.target.value })}
                        placeholder="กรุณาวางลิ้งค์ URL ของสคริปต์เว็บแอป..."
                        className="w-full bg-slate-950/40 border border-slate-800 text-xs text-slate-300 py-2.5 px-3 rounded-lg outline-none font-mono focus:border-indigo-500/50"
                      />
                      <p className="text-[9px] text-slate-500 leading-relaxed">
                        * ระบบมีระบบการบันทึกจัดเก็บใน Local Storage ของบราวเซอร์อยู่แล้วเป็นค่าตั้งต้น หากต้องการเชื่อมต่อสเปรดชีตให้ดึงและเขียนฐานข้อมูล ให้ทำการ Deploy เว็บแอปสคริปต์ใน Google Sheets แล้ววางลิงค์ลงในกล่องข้อความด้านบน
                      </p>
                    </div>
                  </div>
                </div>

                {/* PART D: TRANSACTION LOGS HISTORIES */}
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                    <History className="w-4 h-4" /> ประวัติการทำรายการล่าสุดคลังสินค้า ({history.length})
                  </h4>

                  <div className="max-h-48 overflow-y-auto space-y-2 border border-slate-800/60 p-2 rounded-2xl bg-slate-950/30 pr-1">
                    {history.length === 0 ? (
                      <div className="text-center py-6 text-slate-500 text-xs italic">
                        ไม่มีประวัติการทำรายการ
                      </div>
                    ) : (
                      history.map((h, i) => (
                        <div
                          key={h.id || i}
                          className="p-2.5 bg-slate-900/40 border border-slate-800/40 rounded-xl text-[11px] flex justify-between gap-3"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-1">
                              <span className={`font-bold px-1 py-0.5 rounded text-[9px] uppercase ${
                                h.type === 'เบิก'
                                  ? 'bg-rose-500/15 text-rose-400'
                                  : h.type === 'ยืม'
                                  ? 'bg-blue-500/15 text-blue-400'
                                  : 'bg-emerald-500/15 text-emerald-400'
                              }`}>
                                {h.type}
                              </span>
                              <span className="font-mono text-slate-400">{h.itemCode}</span>
                              <span className="text-slate-500 font-mono">• {h.date}</span>
                            </div>
                            <h6 className="font-bold text-slate-300 truncate mt-1">{h.itemName}</h6>
                            <p className="text-slate-400 text-[10px] mt-0.5">
                              ผู้จัดทำ: <span className="text-slate-200">{h.user}</span>
                              {h.remark && ` (หมายเหตุ: ${h.remark})`}
                            </p>
                          </div>
                          
                          <div className="shrink-0 text-right font-bold text-slate-200 font-mono mt-1">
                            {h.qty}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Reset button action */}
                <div className="pt-4 border-t border-slate-800/40">
                  <button
                    onClick={handleResetToDefault}
                    className="w-full bg-rose-500/10 hover:bg-rose-500 text-rose-400 hover:text-white border border-rose-500/20 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
                  >
                    🗑️ ล้างข้อมูลและรีเซ็ตระบบเป็นค่าเริ่มต้นโรงงาน (Reset System Data)
                  </button>
                </div>

              </div>

              {/* Close footer */}
              <div className="p-4 bg-slate-950/60 border-t border-slate-800/40 flex justify-end shrink-0">
                <button
                  type="button"
                  onClick={() => setIsAdminOpen(false)}
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-5 py-2 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  ปิดหน้าควบคุมแอดมิน
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ── MODAL 3: BARCODE/QR SCANNER OVERLAY ── */}
      <QRScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        items={items}
        onScanSuccess={(code) => handleAddItemToCart(code, activeTab)}
      />

      {/* ── MODAL 4: CART DRAWER SHEET ── */}
      <TransactionModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={activeTab === 'withdraw' ? withdrawCart : borrowCart}
        mode={activeTab}
        onUpdateQty={(idx, qty) => handleUpdateCartQty(idx, qty, activeTab)}
        onRemoveItem={(idx) => handleRemoveCartItem(idx, activeTab)}
        onSubmit={(remark) => handleTransactionSubmit(remark, activeTab)}
        reqRemark={settings.reqRemark}
      />

      {/* ── TOAST LIST (GLOWS FLOATING AT BOTTOM) ── */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[200] flex flex-col gap-2 pointer-events-none w-full max-w-sm px-4">
        {toasts.map(t => (
          <div
            key={t.id}
            className={`p-3.5 rounded-xl border text-xs font-semibold flex items-center gap-2 shadow-xl backdrop-blur-md animate-[slideUp_0.2s_ease-out] ${
              t.type === 'success'
                ? 'bg-[#142321] border-emerald-500/30 text-emerald-400 shadow-emerald-500/5'
                : t.type === 'error'
                ? 'bg-[#29161a] border-rose-500/30 text-rose-400 shadow-rose-500/5'
                : 'bg-slate-900/95 border-slate-700/50 text-slate-200'
            }`}
          >
            <span>{t.type === 'success' ? '✓' : t.type === 'error' ? '✕' : 'ℹ'}</span>
            <span>{t.message}</span>
          </div>
        ))}
      </div>

    </div>
  );
}
