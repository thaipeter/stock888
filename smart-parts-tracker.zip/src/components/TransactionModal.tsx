import React, { useState, useEffect } from 'react';
import { X, Trash2, Plus, Minus, AlertTriangle, Check, CornerDownRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CartItem {
  code: string;
  name: string;
  qty: number;
  unit: string;
  stock: number;
}

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  mode: 'withdraw' | 'borrow';
  onUpdateQty: (index: number, qty: number) => void;
  onRemoveItem: (index: number) => void;
  onSubmit: (remark: string) => Promise<void>;
  reqRemark: boolean;
}

export default function TransactionModal({
  isOpen,
  onClose,
  cart,
  mode,
  onUpdateQty,
  onRemoveItem,
  onSubmit,
  reqRemark
}: TransactionModalProps) {
  const [remark, setRemark] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setRemark('');
      setErrorMsg('');
    }
  }, [isOpen]);

  const quickRemarks = mode === 'withdraw'
    ? ['ซ่อม Line 1', 'ซ่อม Line 2', 'เติมน้ำมันรถตู้', 'ซ่อมบำรุงรักษา PM', 'หน้างานแผนกไฟฟ้า']
    : ['ซ่อมบำรุงปั๊ม', 'ตรวจตู้คอนโทรลไฟฟ้า', 'งาน PM ประจำสัปดาห์', 'ออกหน้างานภายนอก', 'งานเบ็ดเตล็ด'];

  const handleSubmit = async () => {
    setErrorMsg('');
    if (cart.length === 0) {
      setErrorMsg('ไม่มีรายการอะไหล่ในตะกร้า');
      return;
    }

    if (reqRemark && !remark.trim()) {
      setErrorMsg('กรุณากรอกเหตุผลหรือสถานที่นำไปใช้งาน');
      return;
    }

    // Double check stock limits for withdraw mode
    if (mode === 'withdraw') {
      const overStock = cart.some(item => item.qty > item.stock);
      if (overStock) {
        setErrorMsg('มีอะไหล่บางชิ้นระบุจำนวนเกินจำนวนคงเหลือในคลัง');
        return;
      }
    }

    setIsSubmitting(true);
    try {
      await onSubmit(remark);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'เกิดข้อผิดพลาดในการบันทึกรายการ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQtyChange = (index: number, newQty: number) => {
    if (newQty < 1) return;
    const item = cart[index];
    if (mode === 'withdraw' && newQty > item.stock) {
      setErrorMsg('ระบุเกินสต็อกคงเหลือที่มีอยู่จริง');
      return;
    }
    setErrorMsg('');
    onUpdateQty(index, newQty);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-xs z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 animate-[fadeIn_0.2s_ease-out]">
        {/* Backdrop close target */}
        <div className="absolute inset-0" onClick={onClose} />

        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 24, stiffness: 220 }}
          className="w-full sm:max-w-xl bg-slate-900/95 backdrop-blur-md border-t sm:border border-slate-800 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col max-h-[92vh] sm:max-h-[85vh] overflow-hidden relative z-10"
        >
          {/* Header handle for swipe gestures on mobile */}
          <div className="w-12 h-1 bg-slate-800 rounded-full mx-auto my-3 sm:hidden flex-shrink-0" />

          {/* Drawer Title Header */}
          <div className="flex items-center justify-between px-6 pb-4 pt-1 sm:pt-4 border-b border-slate-800/40 bg-slate-900/50 flex-shrink-0">
            <div className="flex items-center gap-2.5">
              <span className={`text-lg p-2 rounded-xl ${mode === 'withdraw' ? 'bg-rose-500/10 text-rose-400' : 'bg-indigo-500/10 text-indigo-400'}`}>
                {mode === 'withdraw' ? '📤' : '🤝'}
              </span>
              <div>
                <h3 className="font-bold text-slate-100 text-base">
                  {mode === 'withdraw' ? 'รายการเบิกจ่ายอะไหล่' : 'รายการขอยืมอุปกรณ์'}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  กรุณาตรวจสอบจำนวนชิ้นงานและบันทึกข้อมูลเพิ่มเติม
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Drawer Cart List Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {errorMsg && (
              <div className="flex items-center gap-2 text-xs font-medium text-rose-500 bg-rose-950/20 border border-rose-900/30 p-3 rounded-xl mb-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400" />
                <span>{errorMsg}</span>
              </div>
            )}

            {cart.length === 0 ? (
              <div className="text-center py-12 text-slate-400 text-sm">
                ไม่มีสินค้าในตะกร้า
              </div>
            ) : (
              cart.map((item, index) => {
                const isOverStock = mode === 'withdraw' && item.qty > item.stock;
                return (
                  <div
                    key={item.code}
                    className={`p-4 rounded-2xl bg-slate-950/30 border transition-colors ${
                      isOverStock ? 'border-rose-500/40 bg-rose-950/20' : 'border-slate-800/60 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4 mb-3">
                      <div className="min-w-0">
                        <span className="text-[10px] uppercase font-mono tracking-wider text-indigo-400 font-semibold">
                          {item.code}
                        </span>
                        <h4 className="font-semibold text-slate-100 text-sm truncate mt-0.5">
                          {item.name}
                        </h4>
                        <div className="flex items-center gap-1.5 mt-1 text-xs text-slate-400">
                          <span>คลังคงเหลือ:</span>
                          <span className={`font-mono font-semibold ${item.stock === 0 ? 'text-rose-500' : 'text-slate-200'}`}>
                            {item.stock} {item.unit}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => onRemoveItem(index)}
                        className="text-slate-500 hover:text-rose-400 p-1.5 hover:bg-rose-500/5 rounded-lg transition-all cursor-pointer flex-shrink-0"
                        title="ลบชิ้นนี้ออก"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Quantity controls */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/40">
                      <span className="text-xs text-slate-400">ระบุจำนวนที่ต้องการ</span>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleQtyChange(index, item.qty - 1)}
                          disabled={item.qty <= 1}
                          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors disabled:opacity-30 cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>

                        <input
                          type="number"
                          value={item.qty}
                          onChange={(e) => {
                            const v = parseInt(e.target.value);
                            handleQtyChange(index, isNaN(v) ? 1 : v);
                          }}
                          className="w-16 h-8 bg-slate-950 border border-slate-800 text-center text-slate-100 font-mono font-bold rounded-lg text-sm focus:border-indigo-500 outline-none"
                        />

                        <button
                          type="button"
                          onClick={() => handleQtyChange(index, item.qty + 1)}
                          disabled={mode === 'withdraw' && item.qty >= item.stock}
                          className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors disabled:opacity-30 cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                        
                        <span className="text-xs text-slate-400 ml-1 font-medium">{item.unit}</span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Drawer Form Footer Controls */}
          <div className="border-t border-slate-800/40 p-6 bg-slate-900/50 flex-shrink-0">
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  ระบุรายละเอียดหรือสถานที่นำไปใช้ {reqRemark && <span className="text-rose-500">*</span>}
                </label>
                <input
                  type="text"
                  value={remark}
                  onChange={(e) => {
                    setRemark(e.target.value);
                    setErrorMsg('');
                  }}
                  placeholder={mode === 'withdraw' ? 'เช่น ซ่อมสายพาน Line 1, เติมเติมปั๊มน้ำชั้น 2' : 'เช่น ช่างสมชาย นำไป PM ตู้คุมระบบไฟ'}
                  className="w-full bg-slate-950/40 border border-slate-800 text-slate-200 py-3 px-4 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all text-sm"
                />

                {/* Quick chip selector */}
                <div className="flex flex-wrap gap-1.5 mt-2.5">
                  {quickRemarks.map((qr) => (
                    <button
                      key={qr}
                      type="button"
                      onClick={() => {
                        setRemark(qr);
                        setErrorMsg('');
                      }}
                      className="text-[11px] bg-slate-800/80 hover:bg-indigo-500/10 hover:text-indigo-400 hover:border-indigo-500/40 text-slate-300 border border-slate-700/50 px-2.5 py-1 rounded-full transition-all cursor-pointer"
                    >
                      {qr}
                    </button>
                  ))}
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={isSubmitting}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-300 py-3.5 rounded-xl text-sm font-semibold transition-all cursor-pointer"
                >
                  ย้อนกลับ
                </button>
                <button
                  type="button"
                  disabled={cart.length === 0 || isSubmitting}
                  onClick={handleSubmit}
                  className="flex-2 py-3.5 rounded-xl text-sm font-bold transition-all shadow-lg flex items-center justify-center gap-1.5 cursor-pointer bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white hover:opacity-90 shadow-indigo-500/10"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>กำลังบันทึกรายการ...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4.5 h-4.5" />
                      <span>{mode === 'withdraw' ? 'ยืนยันการเบิกอะไหล่' : 'ยืนยันการยืมเครื่องมือ'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
