import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { AlertCircle, UserCheck, Key, ArrowRight, ArrowLeft, ChevronDown, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface LoginScreenProps {
  users: User[];
  onLoginSuccess: (user: User) => void;
  onRegisterRequest: (name: string, dept: string, pin: string) => Promise<{ success: boolean; error?: string }>;
}

export default function LoginScreen({ users, onLoginSuccess, onRegisterRequest }: LoginScreenProps) {
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  // Register state
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);
  const [regStep, setRegStep] = useState<number>(1);
  const [regName, setRegName] = useState<string>('');
  const [regDept, setRegDept] = useState<string>('');
  const [regPin, setRegPin] = useState<string>('');
  const [regError, setRegError] = useState<string>('');
  const [isSubmittingReg, setIsSubmittingReg] = useState<boolean>(false);

  // Filter approved users for standard login dropdown
  const approvedUsers = users.filter(u => u.approved);

  useEffect(() => {
    // Check if PIN has reached 4 digits
    if (pin.length === 4 && selectedUserId) {
      handleLogin(pin);
    }
  }, [pin]);

  const handleLogin = (enteredPin: string) => {
    const user = users.find(u => u.userId === selectedUserId);
    if (!user) return;

    setIsVerifying(true);
    setError('');

    // Simulate standard check latency
    setTimeout(() => {
      if (user.pin === enteredPin) {
        onLoginSuccess(user);
      } else {
        setPin('');
        setError('รหัส PIN ไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง');
      }
      setIsVerifying(false);
    }, 400);
  };

  const handleNumPress = (num: string) => {
    if (pin.length < 4) {
      setPin(prev => prev + num);
      setError('');
    }
  };

  const handleBackspace = () => {
    setPin(prev => prev.slice(0, -1));
    setError('');
  };

  // Register Keypad handler
  const handleRegNumPress = (num: string) => {
    if (regPin.length < 4) {
      setRegPin(prev => prev + num);
      setRegError('');
    }
  };

  const handleRegBackspace = () => {
    setRegPin(prev => prev.slice(0, -1));
  };

  const submitRegister = async () => {
    if (!regName.trim()) {
      setRegError('กรุณาระบุชื่อ-นามสกุล');
      setRegStep(1);
      return;
    }
    if (regPin.length < 4) {
      setRegError('กรุณาตั้งรหัส PIN 4 หลัก');
      return;
    }

    setIsSubmittingReg(true);
    setRegError('');

    try {
      const res = await onRegisterRequest(regName, regDept, regPin);
      if (res.success) {
        setRegStep(3);
      } else {
        setRegError(res.error || 'เกิดข้อผิดพลาดในการลงทะเบียน');
      }
    } catch (e: any) {
      setRegError(e.message || 'เกิดข้อผิดพลาด');
    } finally {
      setIsSubmittingReg(false);
    }
  };

  const openRegister = () => {
    setRegName('');
    setRegDept('');
    setRegPin('');
    setRegStep(1);
    setRegError('');
    setIsRegisterOpen(true);
  };

  const closeRegister = () => {
    setIsRegisterOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center px-4 py-8 bg-[#0F172A] relative overflow-hidden">
      {/* Background visual ornaments */}
      <div className="absolute -top-40 -left-40 w-96 h-96 rounded-full bg-indigo-600/15 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 rounded-full bg-emerald-600/10 blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-indigo-500/5 blur-3xl pointer-events-none" />

      {/* Main Container */}
      <div className="w-full max-w-md bento-card p-6 sm:p-8 relative z-10">
        <div className="text-center mb-6 sm:mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 text-white font-bold text-3xl shadow-lg shadow-indigo-500/25 mb-4 animate-[pulse_3s_infinite]">
            🏭
          </div>
          <h1 className="text-2xl font-bold text-slate-100 tracking-tight font-sans">ระบบคลังอะไหล่อัจฉริยะ</h1>
          <p className="text-xs text-slate-400 mt-1">กรุณาเลือกผู้ใช้งานและกรอกรหัสผ่านเพื่อทำรายการ</p>
        </div>

        {/* User Selection */}
        <div className="mb-6">
          <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
            ชื่อผู้ใช้งาน
          </label>
          <div className="relative">
            <select
              value={selectedUserId}
              onChange={(e) => {
                setSelectedUserId(e.target.value);
                setPin('');
                setError('');
              }}
              className="w-full bg-slate-900/60 border border-slate-700/60 hover:border-indigo-500/40 text-slate-200 py-3.5 px-4 pr-10 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all appearance-none text-sm font-medium cursor-pointer"
            >
              <option value="" className="text-slate-500 bg-[#0F172A]">-- เลือกชื่อของคุณ --</option>
              {approvedUsers.map((u) => (
                <option key={u.userId} value={u.userId} className="text-slate-200 bg-[#0F172A]">
                  {u.name} {u.dept ? `(${u.dept})` : ''}
                </option>
              ))}
            </select>
            <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-slate-400">
              <ChevronDown className="w-4 h-4" />
            </div>
          </div>
        </div>

        {/* PIN Numpad Area */}
        <AnimatePresence mode="wait">
          {selectedUserId && (
            <motion.div
              key="pin-area"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="flex flex-col items-center"
            >
              {/* PIN Dot indicators */}
              <div className="flex gap-4 mb-6">
                {[0, 1, 2, 3].map((index) => (
                  <div
                    key={index}
                    className={`w-3.5 h-3.5 rounded-full border-2 transition-all duration-150 ${
                      index < pin.length
                        ? 'bg-indigo-500 border-indigo-500 scale-110 shadow-md shadow-indigo-500/35'
                        : 'border-slate-700 bg-transparent'
                    }`}
                  />
                ))}
              </div>

              {/* Error messages */}
              {error && (
                <div className="flex items-center gap-2 mb-4 text-xs font-medium text-rose-400 bg-rose-950/25 border border-rose-500/25 px-3 py-2 rounded-lg">
                  <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              {/* Virtual Keypad */}
              <div className="grid grid-cols-3 gap-3 w-full max-w-[280px]">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => handleNumPress(num)}
                    disabled={isVerifying}
                    className="h-14 bg-slate-800/40 hover:bg-slate-800/80 active:bg-slate-700/80 border border-slate-700/40 hover:border-indigo-500/30 text-slate-200 font-semibold text-lg rounded-xl flex items-center justify-center transition-all duration-75 active:scale-95 disabled:opacity-50 select-none cursor-pointer"
                  >
                    {num}
                  </button>
                ))}
                <div className="h-14 flex items-center justify-center text-slate-500 font-bold select-none text-xs tracking-widest uppercase">
                  PIN
                </div>
                <button
                  type="button"
                  onClick={() => handleNumPress('0')}
                  disabled={isVerifying}
                  className="h-14 bg-slate-800/40 hover:bg-slate-800/80 active:bg-slate-700/80 border border-slate-700/40 hover:border-indigo-500/30 text-slate-200 font-semibold text-lg rounded-xl flex items-center justify-center transition-all duration-75 active:scale-95 disabled:opacity-50 select-none cursor-pointer"
                >
                  0
                </button>
                <button
                  type="button"
                  onClick={handleBackspace}
                  disabled={isVerifying || pin.length === 0}
                  className="h-14 bg-rose-950/20 active:bg-rose-900/40 border border-rose-500/20 hover:border-rose-500/40 text-rose-400 font-semibold text-sm rounded-xl flex items-center justify-center transition-all duration-75 active:scale-95 disabled:opacity-40 select-none cursor-pointer"
                >
                  ←
                </button>
              </div>

              {/* Status loader overlay */}
              {isVerifying && (
                <div className="mt-4 text-xs text-indigo-400 flex items-center gap-2 font-medium">
                  <div className="w-3 h-3 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                  <span>กำลังเข้าสู่ระบบ...</span>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Footer actions */}
        <div className="mt-8 pt-6 border-t border-slate-800/60 text-center">
          <p className="text-xs text-slate-400">
            ยังไม่มีรายชื่อในระบบ?{' '}
            <button
              onClick={openRegister}
              className="text-indigo-400 hover:text-indigo-300 font-semibold transition-colors cursor-pointer inline-flex items-center gap-0.5"
            >
              สมัครขอเปิดบัญชีใช้งาน <ArrowRight className="w-3 h-3" />
            </button>
          </p>
        </div>
      </div>

      {/* REGISTRATION MODAL */}
      <AnimatePresence>
        {isRegisterOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 280 }}
              className="w-full sm:max-w-md bg-slate-900 border-t sm:border border-slate-800/80 rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl"
            >
              <div className="w-12 h-1 bg-slate-800 rounded-full mx-auto mb-4 sm:hidden" />

              {/* Step Title Header */}
              <div className="mb-5">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                    <span>📝 สมัครใช้งานคลัง</span>
                  </h2>
                  <span className="text-xs bg-slate-800 text-slate-400 px-2 py-1 rounded-md font-mono">
                    ขั้นตอน {regStep}/3
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-1">
                  {regStep === 1 && 'ระบุชื่อและฝ่ายเพื่อส่งข้อมูลขออนุมัติใช้งาน'}
                  {regStep === 2 && 'ตั้งรหัส PIN 4 หลักเพื่อใช้เข้าใช้งานส่วนตัว'}
                  {regStep === 3 && 'ส่งคำร้องขอเสร็จสิ้น'}
                </p>
              </div>

              {regError && (
                <div className="flex items-center gap-2 text-xs font-medium text-rose-400 bg-rose-950/20 border border-rose-900/30 p-3 rounded-lg mb-4">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{regError}</span>
                </div>
              )}

              {/* STEP 1: Name and Department */}
              {regStep === 1 && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      ชื่อ-นามสกุล <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="เช่น สมชาย ใจดี"
                      className="w-full bg-slate-950 border border-slate-700/60 text-slate-200 py-3 px-4 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                      แผนก / ตำแหน่ง
                    </label>
                    <input
                      type="text"
                      value={regDept}
                      onChange={(e) => setRegDept(e.target.value)}
                      placeholder="เช่น ช่างซ่อมบำรุง, ฝ่ายผลิต Line 1"
                      className="w-full bg-slate-950 border border-slate-700/60 text-slate-200 py-3 px-4 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all text-sm"
                    />
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={closeRegister}
                      className="flex-1 bg-slate-800 hover:bg-slate-750 text-slate-300 py-3 rounded-xl text-sm font-semibold transition-all cursor-pointer"
                    >
                      ยกเลิก
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!regName.trim()) {
                          setRegError('กรุณากรอกชื่อ-นามสกุล');
                          return;
                        }
                        setRegError('');
                        setRegStep(2);
                      }}
                      className="flex-1 bg-indigo-500 hover:bg-indigo-400 text-slate-950 py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      ถัดไป <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 2: Choose PIN */}
              {regStep === 2 && (
                <div className="flex flex-col items-center">
                  <div className="flex gap-4 mb-4">
                    {[0, 1, 2, 3].map((index) => (
                      <div
                        key={index}
                        className={`w-3.5 h-3.5 rounded-full border-2 transition-all duration-150 ${
                          index < regPin.length
                            ? 'bg-indigo-500 border-indigo-500 scale-110 shadow-md shadow-indigo-500/35'
                            : 'border-slate-700 bg-transparent'
                        }`}
                      />
                    ))}
                  </div>

                  <div className="text-xs text-slate-400 mb-5 font-mono">
                    {regPin.length < 4 ? 'กรุณาเลือก PIN 4 หลัก' : 'PIN ครบแล้วพร้อมส่งขอเปิดบัญชี'}
                  </div>

                  {/* Keyboard */}
                  <div className="grid grid-cols-3 gap-2.5 w-full max-w-[260px] mb-6">
                    {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => handleRegNumPress(num)}
                        className="h-12 bg-slate-800/50 hover:bg-slate-800 active:bg-slate-700 border border-slate-700/40 text-slate-200 font-semibold rounded-xl flex items-center justify-center transition-all duration-75 select-none cursor-pointer"
                      >
                        {num}
                      </button>
                    ))}
                    <div className="h-12 flex items-center justify-center text-slate-600 font-semibold text-xs tracking-wider">
                      REG
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRegNumPress('0')}
                      className="h-12 bg-slate-800/50 hover:bg-slate-800 active:bg-slate-700 border border-slate-700/40 text-slate-200 font-semibold rounded-xl flex items-center justify-center transition-all duration-75 select-none cursor-pointer"
                    >
                      0
                    </button>
                    <button
                      type="button"
                      onClick={handleRegBackspace}
                      disabled={regPin.length === 0}
                      className="h-12 bg-rose-950/20 text-rose-400 border border-rose-950/20 rounded-xl flex items-center justify-center select-none cursor-pointer"
                    >
                      ←
                    </button>
                  </div>

                  <div className="flex gap-3 w-full pt-4 border-t border-slate-800">
                    <button
                      type="button"
                      onClick={() => setRegStep(1)}
                      className="flex-1 bg-slate-800 hover:bg-slate-750 text-slate-300 py-3 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft className="w-4 h-4" /> ย้อนกลับ
                    </button>
                    <button
                      type="button"
                      disabled={regPin.length < 4 || isSubmittingReg}
                      onClick={submitRegister}
                      className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-400 hover:to-purple-400 text-white py-3 rounded-xl text-sm font-bold transition-all disabled:opacity-40 cursor-pointer"
                    >
                      {isSubmittingReg ? 'กำลังส่งคำร้อง...' : 'ส่งคำขออนุมัติ'}
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Success message */}
              {regStep === 3 && (
                <div className="text-center py-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-500 mb-4 border border-emerald-500/20">
                    <CheckCircle2 className="w-10 h-10 animate-bounce" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-100">ส่งคำร้องเรียบร้อยแล้ว!</h3>
                  <p className="text-sm text-slate-400 mt-2 max-w-xs mx-auto">
                    บัญชีของ <span className="text-indigo-400 font-semibold">{regName}</span> รอรับการอนุมัติเปิดสิทธิ์ใช้งานจาก Admin ถัดไป
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    (รหัสเข้าใช้งานของคุณคือ PIN 4 หลักที่เพิ่งทำการตั้งค่า)
                  </p>

                  <div className="mt-8">
                    <button
                      type="button"
                      onClick={closeRegister}
                      className="w-full bg-indigo-500 hover:bg-indigo-400 text-slate-950 py-3.5 rounded-xl font-bold text-sm transition-all cursor-pointer"
                    >
                      เสร็จสิ้นและกลับหน้าหลัก
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
