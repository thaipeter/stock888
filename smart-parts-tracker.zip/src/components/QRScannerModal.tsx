import React, { useState, useEffect, useRef } from 'react';
import { X, Camera, Keyboard, Check, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Item } from '../types';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: Item[];
  onScanSuccess: (code: string) => void;
}

export default function QRScannerModal({ isOpen, onClose, items, onScanSuccess }: QRScannerModalProps) {
  const [manualCode, setManualCode] = useState<string>('');
  const [useManualInput, setUseManualInput] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [cameraActive, setCameraActive] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<any>(null);

  useEffect(() => {
    if (isOpen && !useManualInput) {
      startCamera();
    } else {
      stopCamera();
    }

    return () => {
      stopCamera();
    };
  }, [isOpen, useManualInput]);

  const startCamera = async () => {
    setErrorMsg('');
    setCameraActive(false);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
          setCameraActive(true);

          // Dynamically try to load jsqr or use simple checking
          // We can run an interval to grab video frames and search for a simulated code,
          // or if jsqr is loaded on the window we can use it.
          intervalRef.current = setInterval(() => {
            decodeFrame();
          }, 300);
        }
      } else {
        throw new Error('เบราว์เซอร์ไม่รองรับกล้องในหน้านี้');
      }
    } catch (err: any) {
      console.warn('Camera failed to start:', err);
      // Fallback to manual mode automatically
      setUseManualInput(true);
      setErrorMsg('ไม่สามารถเข้าถึงกล้องถ่ายภาพได้ เปลี่ยนเส้นทางไปยังโหมดกรอกรหัสแทน');
    }
  };

  const stopCamera = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const decodeFrame = () => {
    const video = videoRef.current;
    if (!video || video.readyState !== video.HAVE_ENOUGH_DATA) return;

    if (!canvasRef.current) {
      canvasRef.current = document.createElement('canvas');
    }
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    
    // If jsQR is available globally (from script tag or similar) we can call it.
    const globalJsQR = (window as any).jsQR;
    if (globalJsQR) {
      try {
        const code = globalJsQR(imgData.data, imgData.width, imgData.height);
        if (code && code.data) {
          const cleanedCode = code.data.replace(/^SCAN:/i, '').trim();
          handleFoundCode(cleanedCode);
        }
      } catch (e) {
        console.error('jsQR error:', e);
      }
    }
  };

  const handleFoundCode = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const itemExists = items.some(item => item.code.toUpperCase() === cleanCode);

    if (itemExists) {
      onScanSuccess(cleanCode);
      onClose();
    } else {
      setErrorMsg(`ไม่พบรายการอะไหล่รหัส "${cleanCode}" ในระบบ`);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!manualCode.trim()) {
      setErrorMsg('กรุณากรอกรหัสสินค้า');
      return;
    }
    handleFoundCode(manualCode);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-sm z-50 flex flex-col justify-center items-center p-4 animate-[fadeIn_0.2s_ease-out]">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="w-full max-w-md bg-slate-900/95 backdrop-blur-md border border-slate-800/80 rounded-3xl overflow-hidden shadow-2xl relative"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-5 border-b border-slate-800/40 bg-slate-900/50">
            <div className="flex items-center gap-2">
              <span className="text-xl">📸</span>
              <h3 className="font-bold text-slate-100 text-base">สแกนรหัสอะไหล่ / เครื่องมือ</h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Toggle scan modes */}
          <div className="flex p-1 bg-slate-950/40 m-4 rounded-2xl border border-slate-800/60">
            <button
              onClick={() => setUseManualInput(false)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                !useManualInput
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/15'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Camera className="w-3.5 h-3.5" /> สแกนผ่านกล้อง
            </button>
            <button
              onClick={() => setUseManualInput(true)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                useManualInput
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/15'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Keyboard className="w-3.5 h-3.5" /> ป้อนรหัสด้วยตนเอง
            </button>
          </div>

          {/* Error Message Box */}
          {errorMsg && (
            <div className="mx-4 mb-4 flex items-start gap-2 text-xs font-medium text-rose-500 bg-rose-950/20 border border-rose-900/30 p-3 rounded-xl">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-rose-400 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Camera View Mode */}
          {!useManualInput && (
            <div className="flex flex-col items-center justify-center p-6 bg-slate-900/50">
              <div className="relative w-64 h-64 border border-slate-800/80 rounded-2xl overflow-hidden bg-black flex items-center justify-center shadow-inner">
                {/* Simulated scan line */}
                {cameraActive && (
                  <div className="absolute top-0 inset-x-0 h-0.5 bg-indigo-500 shadow-[0_0_8px_#6366f1] animate-[bounce_2s_infinite] z-20" />
                )}

                {/* Corners overlay */}
                <div className="absolute inset-4 border-2 border-dashed border-indigo-500/20 rounded-xl pointer-events-none z-10" />
                <div className="absolute top-3 left-3 w-5 h-5 border-t-3 border-l-3 border-indigo-500 rounded-tl pointer-events-none z-10" />
                <div className="absolute top-3 right-3 w-5 h-5 border-t-3 border-r-3 border-indigo-500 rounded-tr pointer-events-none z-10" />
                <div className="absolute bottom-3 left-3 w-5 h-5 border-b-3 border-l-3 border-indigo-500 rounded-bl pointer-events-none z-10" />
                <div className="absolute bottom-3 right-3 w-5 h-5 border-b-3 border-r-3 border-indigo-500 rounded-br pointer-events-none z-10" />

                {/* Video feed */}
                <video
                  ref={videoRef}
                  className="w-full h-full object-cover"
                  playsInline
                  muted
                />

                {/* Fallback load text */}
                {!cameraActive && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-xs text-slate-500 bg-slate-950 gap-2">
                    <div className="w-6 h-6 border-2 border-slate-500 border-t-transparent rounded-full animate-spin" />
                    <span>กำลังขอสิทธิ์เปิดกล้อง...</span>
                  </div>
                )}
              </div>

              <div className="text-center mt-4">
                <p className="text-xs text-slate-400">หันกล้องหาคิวอาร์โค้ด / บาร์โค้ดของชิ้นงาน</p>
                
                {/* Direct quick simulator selector since we are in development environment */}
                <div className="mt-4 pt-4 border-t border-slate-800/40 w-full">
                  <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                    ทดสอบจำลองรหัสสแกนด่วน (Developer Quick Testing)
                  </span>
                  <div className="flex flex-wrap justify-center gap-1.5">
                    {items.slice(0, 4).map(item => (
                      <button
                        key={item.code}
                        type="button"
                        onClick={() => handleFoundCode(item.code)}
                        className="text-[10px] bg-slate-800/80 hover:bg-indigo-500/10 hover:text-indigo-400 hover:border-indigo-500/40 text-slate-300 border border-slate-700/50 px-2 py-1 rounded transition-all cursor-pointer"
                      >
                        {item.code} ({item.name.slice(0, 6)}...)
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Manual Input Mode */}
          {useManualInput && (
            <form onSubmit={handleManualSubmit} className="p-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                    รหัสสินค้า / บาร์โค้ดอะไหล่
                  </label>
                  <input
                    type="text"
                    value={manualCode}
                    onChange={(e) => {
                      setManualCode(e.target.value);
                      setErrorMsg('');
                    }}
                    placeholder="เช่น BL-001, EL-012, TL-002"
                    className="w-full bg-slate-950/40 border border-slate-800 text-slate-200 py-3.5 px-4 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition-all text-sm font-mono tracking-wider"
                    autoFocus
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-lg shadow-indigo-600/15"
                  >
                    <Check className="w-4 h-4" /> ตรวจสอบและเลือกอะไหล่
                  </button>
                </div>

                {/* List of valid searchable codes for developer guidance */}
                <div className="mt-4 pt-4 border-t border-slate-800/40">
                  <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                    รหัสสินค้าทั้งหมดที่สามารถค้นได้ในระบบคลัง:
                  </span>
                  <div className="max-h-24 overflow-y-auto grid grid-cols-2 gap-1.5 text-[11px] text-slate-400 pr-1">
                    {items.map(item => (
                      <div
                        key={item.code}
                        onClick={() => setManualCode(item.code)}
                        className="bg-slate-950/40 border border-slate-800/60 px-2 py-1.5 rounded hover:border-slate-700 cursor-pointer flex justify-between items-center"
                      >
                        <span className="font-mono text-indigo-400">{item.code}</span>
                        <span className="truncate max-w-[80px] text-slate-400">{item.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
